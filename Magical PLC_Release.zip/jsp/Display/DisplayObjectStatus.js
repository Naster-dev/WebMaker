// UI 상태체크
function UpdateScreen()
{
	ImgButtonOn = "img/Object/Button/on.png"
	ImgButtonOf = "img/Object/Button/of.png"

	document.getElementsByTagName('img')[1].src = X[0] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[2].src = X[1] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[3].src = X[2] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[4].src = X[3] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[5].src = X[4] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[6].src = X[5] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[7].src = X[6] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[8].src = X[7] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[9].src = X[8] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[10].src = X[9] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[11].src = X[10] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[12].src = X[11] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[13].src = X[12] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[14].src = X[13] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[15].src = X[14] == true ? ImgButtonOn : ImgButtonOf;
	document.getElementsByTagName('img')[16].src = X[15] == true ? ImgButtonOn : ImgButtonOf;

	ImgLampRdOn = "img/Object/Lamp/RD/on.png"
	ImgLampRdOf = "img/Object/Lamp/RD/of.png"
	ImgLampYlOn = "img/Object/Lamp/YL/on.png"
	ImgLampYlOf = "img/Object/Lamp/YL/of.png"
	ImgLampGrOn = "img/Object/Lamp/GR/on.png"
	ImgLampGrOf = "img/Object/Lamp/GR/of.png"
	ImgLampBlOn = "img/Object/Lamp/BL/on.png"
	ImgLampBlOf = "img/Object/Lamp/BL/of.png"

	document.getElementsByTagName('img')[17].src = Y[0] == true ? ImgLampRdOn : ImgLampRdOf;
	document.getElementsByTagName('img')[18].src = Y[1] == true ? ImgLampYlOn : ImgLampYlOf;
	document.getElementsByTagName('img')[19].src = Y[2] == true ? ImgLampGrOn : ImgLampGrOf;
	document.getElementsByTagName('img')[20].src = Y[3] == true ? ImgLampBlOn : ImgLampBlOf;
	document.getElementsByTagName('img')[21].src = Y[4] == true ? ImgLampRdOn : ImgLampRdOf;
	document.getElementsByTagName('img')[22].src = Y[5] == true ? ImgLampYlOn : ImgLampYlOf;
	document.getElementsByTagName('img')[23].src = Y[6] == true ? ImgLampGrOn : ImgLampGrOf;
	document.getElementsByTagName('img')[24].src = Y[7] == true ? ImgLampBlOn : ImgLampBlOf;
	document.getElementsByTagName('img')[25].src = Y[8] == true ? ImgLampRdOn : ImgLampRdOf;
	document.getElementsByTagName('img')[26].src = Y[9] == true ? ImgLampYlOn : ImgLampYlOf;
	document.getElementsByTagName('img')[27].src = Y[10] == true ? ImgLampGrOn : ImgLampGrOf;
	document.getElementsByTagName('img')[28].src = Y[11] == true ? ImgLampBlOn : ImgLampBlOf;
	document.getElementsByTagName('img')[29].src = Y[12] == true ? ImgLampRdOn : ImgLampRdOf;
	document.getElementsByTagName('img')[30].src = Y[13] == true ? ImgLampYlOn : ImgLampYlOf;
	document.getElementsByTagName('img')[31].src = Y[14] == true ? ImgLampGrOn : ImgLampGrOf;
	document.getElementsByTagName('img')[32].src = Y[15] == true ? ImgLampBlOn : ImgLampBlOf;
};
